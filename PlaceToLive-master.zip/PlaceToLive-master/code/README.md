Project Title
# Place To Live

Group Members
# Jun Chen
# Saahil Karnik
# Kemar Douglas
# Josh Ritz
